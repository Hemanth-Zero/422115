%{ 

    #include <stdio.h> 
    #include <stdlib.h> 
%} 
%token id 
%% 
E : E '+' T 
    | T 
    ; 
T : T '*' F 
    | F 
    ; 
F : id 
    ; 
%% 
int yyerror(char *s) { 
    printf("ERROR at *\n"); 
    return 0; 
} 
int main() { 
    printf("Enter expression:\n"); 
    yyparse(); 
    return 0; 
}