n = int(input())
lines = []
for _ in range(n):
    lines.append(input().split())
reg1 = ""
reg2 = ""
for l in lines:
    lhs = l[0]
    op1 = l[2]
    op = l[3]
    op2 = l[4]
    if reg1 == "":
        reg1 = lhs
        print("R1 =", op1, op, op2)
    elif reg2 == "":
        reg2 = lhs
        print("R2 =", op1, op, op2)
    else:
        print("R1 = R1", op, "R2")
        reg1 = lhs