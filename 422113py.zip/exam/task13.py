n = int(input("Enter number of productions: "))
productions = {}
for _ in range(n):
    line = input()          # e.g. S->CC or C->cC|d
    lhs, rhs = line.split("->")
    productions[lhs] = rhs.split("|")
start = next(iter(productions))
I0 = [(start + "'", "." + start)]
i = 0
while i < len(I0):
    lhs, rhs = I0[i]   # updated names
    dot = rhs.index(".")
    if dot + 1 < len(rhs):
        sym = rhs[dot + 1]
        if sym in productions:
            for prod in productions[sym]:
                item = (sym, "." + prod)
                if item not in I0:
                    I0.append(item)
    i += 1
print([f"{lhs} -> {rhs}" for lhs, rhs in I0])