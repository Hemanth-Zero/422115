n = int(input())
for _ in range(n):
    l = input().split()
    # constant folding
    if l[2].isdigit():
        a = int(l[2])
        op1 = l[3]
        b = int(l[4])

        # handle * first if exists
        if len(l) > 5:
            op2 = l[5]
            c = int(l[6])

            if op2 == '*':
                b = b * c
            elif op2 == '+':
                b = b + c

        if op1 == '+':
            res = a + b
        elif op1 == '*':
            res = a * b

        print(l[0], "=", res)

    # propagation
    else:
        if l[4] == "0":
            print(l[0], "=", l[2])