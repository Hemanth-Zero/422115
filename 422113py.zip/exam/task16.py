# Read input
declarations = input().split(";")

symbol_table = {}
duplicate_vars = set()

for declaration in declarations:
    declaration = declaration.strip()
    
    if declaration:
        parts = declaration.split()
        
        if len(parts) == 2:
            datatype = parts[0]
            variable = parts[1]

            if variable in symbol_table:
                duplicate_vars.add(variable)
            else:
                symbol_table[variable] = datatype

# Print duplicates
for variable in duplicate_vars:
    print(f"{variable} -> DUPLICATE")