n = int(input("Enter number of productions: "))
productions = []
for _ in range(n):
    productions.append(input())
ops = set()
rhs_map = {}
sr_conflict = False
rr_conflict = False
for p in productions:
    lhs, rhs = p.split("->")
    if len(rhs) == 3 and rhs[0] == "E" and rhs[2] == "E":
        ops.add(rhs[1])
    if rhs in rhs_map:
        rr_conflict = True
    else:
        rhs_map[rhs] = lhs
if len(ops) > 1:
    sr_conflict = True
if rr_conflict:
    print("Reduce-Reduce Conflict")
elif sr_conflict:
    print("Shift-Reduce Conflict -> NOT SLR(1)")
else:
    print("SLR(1) Grammar")