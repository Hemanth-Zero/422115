"""grammar={
    "E": ["E+T","T"],
    "T": ["T*F","F"],
    "F": ["(E)","ID"]
}
for A in grammar:
    alpha=[]
    beta=[]
    for rule in grammar[A]:
        if rule[0]==A:
            alpha.append(rule[1:])
        else:
            beta.append(rule)
    if alpha:
        A1=A+"'"
        print(A,"->",end=" ")
        for b in beta:
            print(b+A1,end=" | ")
        print(A1,"->",end=" ")
        for a in alpha:
            print(a+A1,end=" | ")
        print("ε")
    else:
        print(A,"->"," | ".join(grammar[A]))
"""
grammar = {}
n = int(input("Enter number of non-terminals: "))
for i in range(n):
    A = input("Enter non-terminal: ")
    rules = input("Enter productions (use |): ").split("|")
    grammar[A] = rules
for A in grammar:
    alpha = []
    beta = []
    for rule in grammar[A]:
        if rule[0] == A:
            alpha.append(rule[1:])
        else:
            beta.append(rule)
    if alpha:
        A1 = A + "'"
        print(A, "->", end=" ")
        for b in beta:
            print(b + A1, end=" | ")
        print()

        print(A1, "->", end=" ")
        for a in alpha:
            print(a + A1, end=" | ")
        print("ε")
    else:
        print(A, "->", " | ".join(grammar[A]))