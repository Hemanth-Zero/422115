expr = input().replace(" ", "")
temp = 1
stack = []
res = []
for ch in expr:
    if ch != ')':
        stack.append(ch)
    else:
        r = stack.pop()
        op = stack.pop()
        l = stack.pop()
        stack.pop()   # remove '('
        t = "t" + str(temp)
        res.append(t + " = " + l + " " + op + " " + r)
        stack.append(t)
        temp += 1
if "*" in stack:
    r = stack.pop()
    op = stack.pop()
    l = stack.pop()
    t = "t" + str(temp)
    res.append(t + " = " + l + " " + op + " " + r)
    stack.append(t)
lhs = expr.split("=")[0]
res.append(lhs + " = " + stack[-1])
for i in res:
    print(i)
print(res)