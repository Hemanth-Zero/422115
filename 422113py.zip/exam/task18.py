"""code = input().replace(";", "").split()
types = {}
for i in range(len(code)):
    if code[i] in ["int", "float", "bool"]:
        types[code[i+1]] = code[i]
# check assignments
for i in range(len(code)):
    if code[i] == "=":
        var = code[i-1]
        op1 = code[i+1]
        op2 = code[i+3]
        # detect bool
        if op1 in ["true","false"] or op2 in ["true","false"]:
            print(f"{var} = {op1} + {op2} -> ERROR")
        # detect float
        elif types.get(op1) == "float" or types.get(op2) == "float":
            if types[var] == "int":
                print(f"{var} = {op1} + {op2} -> VALID (float → int may warn)")
            else:
                print(f"{var} = {op1} + {op2} -> VALID")
        else:
            print(f"{var} = {op1} + {op2} -> VALID")
"""

inp=input().replace(";","").split()
types={}
for i in range(len(inp)):
    if inp[i] in ["int","float","bool"]:
        types[inp[i+1]]=inp[1]
for i in range(len(inp)):
    if inp[i]=='=':
        var=inp[i-1]
        op1=inp[i+1]
        op2=inp[i+3]
        if op1 in ['True','False'] or op2 in ['true','false']:
            print(f"{var} = {op1} + {op2} NOT VALID\n")
        elif types.get(op1)=='float' or types.get(op2)=="float":
            if types.get(var)=='int':
                print(f"{var} = {op1} + {op2} VALID(implict conversion of into->float\n")
            else:
                print(f"{var} = {op1} + {op2} VALID")
        else:
            print(f"{var} = {op1} + {op2} VALID")