values = {}

while True:
    line = input()
    if line == "":
        break

    statements = line.split(";")

    for s in statements:
        if s == "":
            continue

        left, right = s.split("=")

        left = left
        right = right

        if right.isdigit():
            values[left] = right
            print(left, "=", right)

        else:
            parts = right.split()

            if len(parts) != 3:
                print("INVALID:", s)
                continue

            a, op, b = parts

            print(left, "=", a, op, b)
            values[left] = right