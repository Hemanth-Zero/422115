"""code = input().split()
stack = [{}]
y = 0
i = 0
while i < len(code):
    if code[i] == "{":
        stack.append({})
    elif code[i] == "}":
        stack.pop()
    elif code[i] in ["int", "float", "char"]:
        var = code[i+1]
        val = code[i+3]
        if val.isalpha():  # if variable
            for s in reversed(stack):
                if val in s:
                    val = s[val]
                    break
        stack[-1][var] = int(val)
        if var == "y":
            y = val
        i += 3
    i += 1
print("Inner y uses x =", y)"""






inp = input().replace(";", "").split()

stack = [{}]
y = 0
i = 0

while i < len(inp):

    if inp[i] == '{':
        stack.append({})

    elif inp[i] == '}':
        stack.pop()

    elif inp[i] in ['int', 'float', 'char']:

        var = inp[i + 1]
        val = inp[i + 3]

        # resolve if variable
        if val.isalpha():
            for s in reversed(stack):
                if val in s:
                    val = s[val]
                    break

        stack[-1][var] = int(val)

        if var == 'y':
            y = val

        i += 3

    i += 1

print("Inner y uses x =", y)