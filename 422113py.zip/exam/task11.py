n = int(input("Enter number of productions: "))
productions = {}
for _ in range(n):
    line = input()   # e.g., S->aA|aB
    lhs, rhs = line.split("->")
    productions[lhs] = rhs.split("|")
table = {}
conflict = False
for lhs in productions:
    for rhs in productions[lhs]:
        first = rhs[0]   # taking first symbol directly
        if (lhs, first) in table:
            print(f"Conflict at M[{lhs}, {first}] -> NOT LL(1)")
            conflict = True
        else:
            table[(lhs, first)] = rhs
if not conflict:
    print("\nLL(1) Parsing Table:")
    for key in table:
        print(f"M[{key[0]}, {key[1]}] = {key[0]} -> {table[key]}")