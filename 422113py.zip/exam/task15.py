expr = input().split()
ops = {"+", "-", "*", "/", "%", "^", "="}
valid = True
for i in range(len(expr) - 1):
    if expr[i] in ops and expr[i+1] in ops:
        valid = False
if expr[0] in ops or expr[-1] in ops:
    valid = False
print("VALID" if valid else "ERROR (invalid sequence)")