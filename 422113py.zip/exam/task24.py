n = int(input())
expr = {}   
val = {}    
t = 1
lines = []
for _ in range(n):
    l = input().split()
    lines.append(l)
for l in lines[:-1]:
    lhs = l[0]
    op1 = l[2]
    op = l[3]
    op2 = l[4]
    key = op1 + op + op2
    if key not in expr:
        temp = "t" + str(t)
        expr[key] = temp
        print(temp, "=", op1, op, op2)
        t += 1
    val[lhs] = expr[key]
l = lines[-1]
lhs = l[0]
op1 = val[l[2]]
op = l[3]
op2 = val[l[4]]
print(lhs, "=", op1, op, op2)
