%{
#include <stdio.h>

int sym[26];
int yylex();
int yyerror(char *s);
%}

%token NUM ID

%%

S : S E
  | E
  ;

E : ID '=' EXP
  {
      sym[$1 - 'a'] = $3;
      printf("%c = %d\n", $1, $3);
  }
  ;

EXP : EXP '+' EXP   { $$ = $1 + $3; }
    | EXP '*' EXP   { $$ = $1 * $3; }
    | NUM           { $$ = $1; }
    | ID            { $$ = sym[$1 - 'a']; }
    ;

%%

int yyerror(char *s)
{
    printf("ERROR\n");
    return 0;
}

int main()
{
    for(int i=0;i<26;i++) sym[i]=0;   // 🔥 IMPORTANT FIX
    yyparse();
    return 0;
}