# Input
n = int(input("Enter number of productions: "))
productions = {}
for _ in range(n):
    line = input()             
    lhs, rhs = line.split("->")
    productions[lhs] = rhs.split("|")
FIRST = {nt: set() for nt in productions}
FOLLOW = {nt: set() for nt in productions}
start = list(productions.keys())[0]
FOLLOW[start].add("$")
# -------- FIRST --------
for nt in productions:
    for rhs in productions[nt]:
        if rhs == "ε":
            FIRST[nt].add("ε")
        else:
            for ch in rhs:
                if ch not in productions:
                    FIRST[nt].add(ch)
                    break
                else:
                    FIRST[nt] |= (FIRST[ch] - {"ε"})
                    if "ε" not in FIRST[ch]:
                        break
            else:
                FIRST[nt].add("ε")

# -------- FOLLOW --------
for lhs in productions:
    for rhs in productions[lhs]:
        for i in range(len(rhs)):
            if rhs[i] in productions:
                if i+1 < len(rhs):
                    next_sym = rhs[i+1]
                    if next_sym not in productions:
                        FOLLOW[rhs[i]].add(next_sym)
                    else:
                        FOLLOW[rhs[i]] |= (FIRST[next_sym] - {"ε"})
                        if "ε" in FIRST[next_sym]:
                            FOLLOW[rhs[i]] |= FOLLOW[lhs]

                else:
                    FOLLOW[rhs[i]] |= FOLLOW[lhs]

# -------- Output --------
print("\nFIRST:")
for nt in FIRST:
    print(f"{nt} = {FIRST[nt]}")

print("\nFOLLOW:")
for nt in FOLLOW:
    print(f"{nt} = {FOLLOW[nt]}")