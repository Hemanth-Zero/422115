%{
#include <stdio.h>

int yylex();
void yyerror(char *s);
%}

%token ID

%%

E : T Eprime ;

Eprime : '+' T Eprime
       | /* empty */
       ;

T : F Tprime ;

Tprime : '*' F Tprime
       | /* empty */
       ;

F : '(' E ')'
  | ID
  ;

%%

void yyerror(char *s){
    printf("Invalid Expression\n");
}

int main(){
    printf("Enter expression:\n");
    yyparse();
    printf("Valid Expression\n");
    return 0;
}