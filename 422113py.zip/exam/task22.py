n = int(input())
expr = {}
t = 1
for _ in range(n):
    line = input().split()  
    lhs = line[0]
    rhs = line[2] + line[3] + line[4]   
    if rhs in expr:
        print(lhs, "=", expr[rhs])
    else:
        temp = "t" + str(t)
        expr[rhs] = temp
        print(temp, "=", line[2], line[3], line[4])
        print(lhs, "=", temp)
        t += 1