expr = input().split()
stack = []
postfix = []
for ch in expr:
    if ch.isalpha():
        postfix.append(ch)
    else:
        while stack and stack[-1] == '*':
            postfix.append(stack.pop())
        stack.append(ch)
while stack:
    postfix.append(stack.pop())

# Step 2: TAC
stack2 = []
res = []
temp = 1

for ch in postfix:
    if ch.isalpha():
        stack2.append(ch)
    else:
        b = stack2.pop()
        a = stack2.pop()
        t = "t" + str(temp)
        res.append(t + " = " + a + " " + ch + " " + b)
        stack2.append(t)
        temp += 1
# Output
print("Postfix:", " ".join(postfix))
print("TAC:")
for i in res:
    print(i)