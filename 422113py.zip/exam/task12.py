tokens = input("Enter input: ").split()
ops = ["+", "-", "*", "/"]
i = 0
# First must be id
if i < len(tokens) and tokens[i] == "id":
    i += 1
else:
    print("ERROR at", tokens[i])
    exit()

# Then (op id) repeat
while i < len(tokens):
    if tokens[i] in ops:
        i += 1
    else:
        print("ERROR at", tokens[i])
        exit()

    if i < len(tokens) and tokens[i] == "id":
        i += 1
    else:
        print("ERROR at", tokens[i])
        exit()
print("String Accepted ✅")