#include <stdio.h>
#include <string.h>

/* 2 registers: R1, R2
   t1 = a + b
   t2 = c + d
   t3 = t1 + t2 */
typedef struct { char var[16]; int inUse; } Reg;
Reg regs[2] = {{"",0},{"",0}};

int allocReg(const char *var) {
    for (int i=0;i<2;i++) if (!regs[i].inUse) {
        regs[i].inUse=1; strcpy(regs[i].var,var); return i;
    }
    /* Spill R1 (simple strategy) */
    printf("  SPILL %s to memory\n", regs[0].var);
    regs[0].inUse=1; strcpy(regs[0].var,var); return 0;
}

void freeReg(const char *var) {
    for (int i=0;i<2;i++) if (strcmp(regs[i].var,var)==0) regs[i].inUse=0;
}

int main() {
    printf("Register Allocation (2 registers):\n\n");
    int r1=allocReg("t1"); printf("R%d = a + b (t1)\n",r1+1);
    int r2=allocReg("t2"); printf("R%d = c + d (t2)\n",r2+1);
    printf("R%d = R%d + R%d (t3 = t1 + t2)\n",r1+1,r1+1,r2+1);
    return 0;
}
