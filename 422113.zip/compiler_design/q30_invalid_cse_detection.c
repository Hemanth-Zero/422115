#include <stdio.h>
#include <string.h>

/* Block:
   a = b + c
   c = 5
   d = b + c  <- c changed! CSE of (b+c) is NOT valid here */
typedef struct { char lhs[8]; char op1[8]; char op[4]; char op2[8]; } Inst;

int main() {
    Inst block[] = {
        {"a","b","+","c"},
        {"c","5","",""},   /* c = 5 */
        {"d","b","+","c"},
    };
    int n = 3;
    char dirty[16][8]; int nd=0;
    int hasComputed=0;

    printf("Analyzing basic block for CSE safety:\n\n");
    for (int i=0;i<n;i++) {
        Inst *ins = &block[i];
        if (strlen(ins->op)==0) {
            printf("  %s = %s  [assignment — invalidates expr containing '%s']\n",
                ins->lhs, ins->op1, ins->lhs);
            strcpy(dirty[nd++], ins->lhs);
            hasComputed=0;
        } else {
            int safe=1;
            for (int j=0;j<nd;j++)
                if (strcmp(dirty[j],ins->op1)==0||strcmp(dirty[j],ins->op2)==0) safe=0;
            if (!safe)
                printf("  %s = %s %s %s  [CSE NOT valid — operand modified]\n",
                    ins->lhs,ins->op1,ins->op,ins->op2);
            else {
                printf("  %s = %s %s %s  [safe to CSE]\n",
                    ins->lhs,ins->op1,ins->op,ins->op2);
                hasComputed=1;
            }
        }
    }
    printf("\nConclusion: Common Subexpression Elimination NOT valid for (b+c).\n");
    printf("Reason: 'c' is reassigned between the two uses of (b+c).\n");
    return 0;
}
