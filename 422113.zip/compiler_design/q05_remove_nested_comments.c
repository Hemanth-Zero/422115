#include <stdio.h>
#include <string.h>

void removeComments(const char *src) {
    int i = 0, depth = 0, len = strlen(src);
    while (i < len) {
        if (src[i]=='/' && src[i+1]=='*') { depth++; i+=2; }
        else if (src[i]=='*' && src[i+1]=='/') {
            if (depth > 0) depth--;
            i+=2;
        } else {
            if (depth == 0) putchar(src[i]);
            i++;
        }
    }
    putchar('\n');
}

int main() {
    const char *input =
        "a = b + c; /* start comment x = y + z; */ d = e + f; /* nested /* ignore */ still */";
    removeComments(input);
    return 0;
}
