#include <stdio.h>

/* a = 2 + 3 * 4 => fold to 14
   b = a + 0    => simplify to b = a */
int foldAdd(int x, int y) { return x + y; }
int foldMul(int x, int y) { return x * y; }

int main() {
    /* Constant folding: 2 + 3*4 = 2 + 12 = 14 */
    int mul_result = foldMul(3, 4);
    int a_val = foldAdd(2, mul_result);
    printf("a = %d\n", a_val); /* a = 14 */

    /* Constant propagation: b = a + 0 => b = a (identity elimination) */
    printf("b = a\n");
    return 0;
}
