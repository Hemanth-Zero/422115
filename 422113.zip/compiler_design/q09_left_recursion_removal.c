#include <stdio.h>

int main() {
    /* Original grammar:
       E -> E + T | T
       T -> T * F | F
       F -> (E) | id

       After removing left recursion:
       E -> T E'
       E' -> + T E' | eps
       T -> F T'
       T' -> * F T' | eps
       F unchanged.
    */
    printf("After Left Recursion Removal:\n\n");
    printf("E  -> T E'\n");
    printf("E' -> + T E' | eps\n");
    printf("T  -> F T'\n");
    printf("T' -> * F T' | eps\n");
    printf("F  -> ( E ) | id\n");
    return 0;
}
