#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isKeyword(const char *s) {
    return strcmp(s,"if")==0 || strcmp(s,"while")==0;
}

int isValidId(const char *s) {
    if (!isalpha(s[0]) && s[0]!='_') return 0;
    for (int i=1; s[i]; i++)
        if (!isalnum(s[i]) && s[i]!='_') return 0;
    return 1;
}

int main() {
    char *tokens[] = {"if","ifx","while","while1","if_else","while_","if1","whileif"};
    int n = 8;
    for (int i = 0; i < n; i++) {
        if (isKeyword(tokens[i])) printf("%s -> KEYWORD\n", tokens[i]);
        else if (isValidId(tokens[i])) printf("%s -> IDENTIFIER\n", tokens[i]);
        else printf("%s -> INVALID\n", tokens[i]);
    }
    return 0;
}
