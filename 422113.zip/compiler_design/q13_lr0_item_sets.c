#include <stdio.h>

/* Grammar (augmented):
   S' -> S
   S  -> CC
   C  -> cC | d
*/
int main() {
    printf("LR(0) Canonical Item Sets:\n\n");
    printf("I0:\n");
    printf("  S' -> .S\n");
    printf("  S  -> .CC\n");
    printf("  C  -> .cC\n");
    printf("  C  -> .d\n\n");
    printf("I1 (goto I0 on S):\n");
    printf("  S' -> S.\n\n");
    printf("I2 (goto I0 on C):\n");
    printf("  S  -> C.C\n");
    printf("  C  -> .cC\n");
    printf("  C  -> .d\n\n");
    printf("I3 (goto I0 on c):\n");
    printf("  C  -> c.C\n");
    printf("  C  -> .cC\n");
    printf("  C  -> .d\n\n");
    printf("I4 (goto I0 on d):\n");
    printf("  C  -> d.\n\n");
    printf("I5 (goto I2 on C):\n");
    printf("  S  -> CC.\n\n");
    printf("I6 (goto I2 on c):\n");
    printf("  C  -> c.C\n");
    printf("  C  -> .cC\n");
    printf("  C  -> .d\n\n");
    printf("I7 (goto I2 on d):\n");
    printf("  C  -> d.\n\n");
    printf("I8 (goto I3 on C):\n");
    printf("  C  -> cC.\n\n");
    printf("I9 (goto I6 on C):\n");
    printf("  C  -> cC.\n\n");
    return 0;
}
