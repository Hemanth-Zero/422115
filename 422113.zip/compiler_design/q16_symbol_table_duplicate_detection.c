#include <stdio.h>
#include <string.h>

#define MAX 100
typedef struct { char name[32]; char type[16]; } Symbol;
Symbol table[MAX];
int count = 0;

int lookup(const char *name) {
    for (int i = 0; i < count; i++)
        if (strcmp(table[i].name, name)==0) return i;
    return -1;
}

void insert(const char *type, const char *name) {
    if (lookup(name) >= 0)
        printf("%s -> DUPLICATE\n", name);
    else {
        strcpy(table[count].name, name);
        strcpy(table[count].type, type);
        count++;
        printf("%s -> INSERTED (%s)\n", name, type);
    }
}

int main() {
    insert("int",   "x");
    insert("float", "y");
    insert("int",   "x");
    insert("char",  "y");
    return 0;
}
