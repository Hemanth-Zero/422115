#include <stdio.h>
#include <string.h>

typedef struct { char lhs[8]; char op1[8]; char op[4]; char op2[8]; } Expr;
Expr computed[64]; int nc = 0;
int tc = 1;

char* getOrCompute(char *out, const char *a, const char *op, const char *b) {
    for (int i = 0; i < nc; i++)
        if (strcmp(computed[i].op1,a)==0 && strcmp(computed[i].op,op)==0
            && strcmp(computed[i].op2,b)==0)
            return computed[i].lhs;
    sprintf(out,"t%d",tc++);
    printf("%s = %s %s %s\n", out, a, op, b);
    strcpy(computed[nc].lhs,out);
    strcpy(computed[nc].op1,a);
    strcpy(computed[nc].op,op);
    strcpy(computed[nc].op2,b);
    nc++;
    return out;
}

int main() {
    char t1[8]="",t2[8]="";
    char *r1 = getOrCompute(t1,"b","+","c");
    printf("a = %s\n", r1);
    char *r2 = getOrCompute(t2,"b","+","c");
    printf("d = %s\n", r2);
    return 0;
}
