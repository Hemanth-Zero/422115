#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* Rules: INTEGER = [0-9]+
          FLOAT = [0-9]+\.[0-9]+
          INVALID = .123 | 123. | 12.3.4 */
const char* classify(const char *s) {
    int n = strlen(s), dots = 0, dot_pos = -1;
    for (int i = 0; i < n; i++) {
        if (s[i]=='.') { dots++; dot_pos = i; }
        else if (!isdigit(s[i])) return "INVALID";
    }
    if (dots == 0) return "INTEGER";
    if (dots == 1 && dot_pos > 0 && dot_pos < n-1) return "FLOAT";
    return "INVALID";
}

int main() {
    char *inputs[] = {"123","12.34",".123","123.","12.3.4","0.001","0012"};
    int n = 7;
    for (int i = 0; i < n; i++)
        printf("%s -> %s\n", inputs[i], classify(inputs[i]));
    return 0;
}
