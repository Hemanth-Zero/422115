#include <stdio.h>

/* Generate TAC for: a = (b + c) * (d - e) */
int temp = 1;
char* newTemp(char *buf) {
    sprintf(buf, "t%d", temp++);
    return buf;
}

int main() {
    char t1[8], t2[8], t3[8];
    newTemp(t1); printf("%s = b + c\n", t1);
    newTemp(t2); printf("%s = d - e\n", t2);
    newTemp(t3); printf("%s = %s * %s\n", t3, t1, t2);
    printf("a = %s\n", t3);
    return 0;
}
