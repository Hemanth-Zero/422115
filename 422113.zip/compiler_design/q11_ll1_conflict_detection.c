#include <stdio.h>

/* Grammar: S -> aA | aB, A -> b, B -> c
   FIRST(aA) = {a}, FIRST(aB) = {a}
   Both alternatives start with 'a' => conflict at M[S, a] */
int main() {
    printf("Grammar:\n  S -> aA | aB\n  A -> b\n  B -> c\n\n");
    printf("FIRST(aA) = {a}\n");
    printf("FIRST(aB) = {a}\n\n");
    printf("LL(1) Parsing Table:\n");
    printf("+-----------+--------------------+\n");
    printf("| NonTerminal|        a           |\n");
    printf("+-----------+--------------------+\n");
    printf("| S         | aA, aB <- CONFLICT |\n");
    printf("| A         | b                  |\n");
    printf("| B         | c                  |\n");
    printf("+-----------+--------------------+\n\n");
    printf("Result: Conflict at M[S, a] -> NOT LL(1)\n");
    printf("Reason: Two productions S->aA and S->aB have same FIRST terminal 'a'.\n");
    return 0;
}
