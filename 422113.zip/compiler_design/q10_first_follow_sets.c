#include <stdio.h>

/* Grammar:
   S -> AB
   A -> aA | eps
   B -> bB | eps

   FIRST(A) = {a, eps}
   FIRST(B) = {b, eps}
   FIRST(S) = {a} U FIRST(B) = {a, b, eps}

   FOLLOW(S) = {$}
   FOLLOW(A) = FIRST(B) - {eps} U FOLLOW(S) = {b, $}
   FOLLOW(B) = FOLLOW(S) = {$}
*/
int main() {
    printf("Grammar:\n");
    printf("  S -> AB\n");
    printf("  A -> aA | eps\n");
    printf("  B -> bB | eps\n\n");
    printf("FIRST(S) = { a, b, eps }\n");
    printf("FIRST(A) = { a, eps }\n");
    printf("FIRST(B) = { b, eps }\n\n");
    printf("FOLLOW(S) = { $ }\n");
    printf("FOLLOW(A) = { b, $ }\n");
    printf("FOLLOW(B) = { $ }\n");
    return 0;
}
