#include <stdio.h>

/* Grammar: S -> aA | bA | aB, A -> c, B -> d
   FIRST(aA) = {a}, FIRST(aB) = {a} => conflict on 'a' */
int main() {
    printf("Original Grammar:\n");
    printf("  S -> aA | bA | aB\n");
    printf("  A -> c\n");
    printf("  B -> d\n\n");
    printf("FIRST(aA) = {a}, FIRST(aB) = {a}\n");
    printf("Conflict at M[S, a]: both aA and aB apply.\n\n");
    printf("Fix: Left Factor on 'a':\n");
    printf("  S -> aX | bA\n");
    printf("  X -> A | B\n");
    printf("  A -> c\n");
    printf("  B -> d\n\n");
    printf("Now FIRST(A)={c}, FIRST(B)={d} => no conflict in X.\n");
    printf("Result: Grammar is now LL(1).\n");
    return 0;
}
