#include <stdio.h>
#include <string.h>

/* Grammar (standard expression grammar, LL(1)):
   E -> T E'
   E' -> + T E' | eps
   T -> F T'
   T' -> * F T' | eps
   F -> id
   Parse: id + * id */
const char *tokens[] = {"id","+","*","id","$"};
int pos = 0;

const char* peek() { return tokens[pos]; }
void advance() { pos++; }

void F() {
    if (strcmp(peek(),"id")==0) { printf("Match id\n"); advance(); }
    else printf("ERROR: expected id, got '%s'\n", peek());
}

void Tp() {
    if (strcmp(peek(),"*")==0) { printf("Match *\n"); advance(); F(); Tp(); }
}

void T() { F(); Tp(); }

void Ep() {
    if (strcmp(peek(),"+")==0) { printf("Match +\n"); advance(); T(); Ep(); }
}

void E() { T(); Ep(); }

int main() {
    printf("Parsing: id + * id\n\n");
    E();
    if (strcmp(peek(),"$")!=0)
        printf("ERROR at '%s'\n", peek());
    else
        printf("Parse successful\n");
    return 0;
}
