#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isValid(const char *s) {
    int n = strlen(s);
    if (n < 2 || s[0] != '_' || s[n-1] != '_') return 0;
    int i = 1;
    while (i < n-1) {
        if (isalpha(s[i])) { i++; }
        else if (s[i] == '_') { i++; }
        else if (isdigit(s[i])) {
            if (s[i-1] != '_') return 0;
            while (i < n && isdigit(s[i])) i++;
            if (s[i] != '_') return 0;
        } else return 0;
    }
    return 1;
}

int main() {
    char *t[] = {"_123abc_","123abc","_9x_","__12__","_1a2b_","a_123_"};
    int n = 6;
    for (int i = 0; i < n; i++)
        printf("%s -> %s\n", t[i], isValid(t[i]) ? "VALID" : "INVALID");
    return 0;
}
