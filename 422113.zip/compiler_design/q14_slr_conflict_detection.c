#include <stdio.h>

/* Grammar: E -> E+E | E*E | id (ambiguous)
   This is inherently ambiguous, causing shift-reduce conflicts in SLR. */
int main() {
    printf("Grammar: E -> E + E | E * E | id\n\n");
    printf("The grammar is AMBIGUOUS.\n");
    printf("LR(0) items will have states where on input '+' or '*',\n");
    printf("both SHIFT and REDUCE are possible.\n\n");
    printf("Example conflict state after parsing E + E:\n");
    printf("  Items: E -> E+E.   [can REDUCE]\n");
    printf("         E -> E.+E   [can SHIFT '+']\n");
    printf("         E -> E.*E   [can SHIFT '*']\n\n");
    printf("FOLLOW(E) = {+, *, $}\n");
    printf("Since '+' in FOLLOW(E) and SHIFT('+') both present:\n");
    printf("  -> Shift-Reduce Conflict\n\n");
    printf("Result: NOT SLR(1)\n");
    return 0;
}
