#include <stdio.h>
#include <string.h>
#include <ctype.h>

int isValidIdentifier(const char *s) {
    int n = strlen(s);
    if (n == 0) return 0;
    if (!isalpha(s[0]) && s[0] != '_') return 0;
    int consec = 0;
    for (int i = 0; i < n; i++) {
        if (!isalnum(s[i]) && s[i] != '_') return 0;
        if (isdigit(s[i])) { consec++; if (consec > 2) return 0; }
        else consec = 0;
    }
    return 1;
}

int main() {
    char *tokens[] = {"abc","a12b","a123b","_a99","x999y","_12a_","__123__","a1b2c3"};
    int n = 8;
    for (int i = 0; i < n; i++)
        printf("%s -> %s\n", tokens[i], isValidIdentifier(tokens[i]) ? "VALID" : "INVALID");
    return 0;
}
