#include <stdio.h>
#include <string.h>

/* a = b + c
   d = b + c  <- same as above, share node
   e = a + d  <- both a and d point to same node t1 */
typedef struct { int left; int right; char op; char label[8]; } Node;
Node dag[64]; int ndag = 0;

int findNode(int l, int r, char op) {
    for (int i = 0; i < ndag; i++)
        if (dag[i].left==l && dag[i].right==r && dag[i].op==op) return i;
    return -1;
}

int addNode(int l, int r, char op, const char *lbl) {
    int f = findNode(l, r, op);
    if (f >= 0) return f;
    dag[ndag].left=l; dag[ndag].right=r; dag[ndag].op=op;
    strcpy(dag[ndag].label, lbl);
    return ndag++;
}

int addLeaf(const char *name) {
    for (int i=0;i<ndag;i++) if (strcmp(dag[i].label,name)==0) return i;
    dag[ndag].left=-1; dag[ndag].right=-1; dag[ndag].op=0;
    strcpy(dag[ndag].label,name);
    return ndag++;
}

int main() {
    int nb=addLeaf("b"), nc=addLeaf("c");
    int t1=addNode(nb,nc,'+',"t1");
    printf("t1 = b + c\n");

    int nd=t1; /* d = b+c reuses same node */

    /* e = a + d -> a=t1, d=t1 */
    int ne=addNode(t1,nd,'+',"e");
    printf("e = t1 + t1\n");

    printf("\nDAG shows 'b+c' computed once (node t1).\n");
    printf("Both a and d reference t1.\n");
    return 0;
}
