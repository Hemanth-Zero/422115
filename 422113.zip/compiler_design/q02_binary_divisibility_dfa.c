#include <stdio.h>
#include <string.h>

/* DFA states = remainder mod 3 (0,1,2)
   Transition: state*2 + bit, mod 3 */
int divisibleBy3(const char *s) {
    int state = 0;
    for (int i = 0; s[i]; i++) {
        if (s[i] != '0' && s[i] != '1') return 0;
        state = (state * 2 + (s[i] - '0')) % 3;
    }
    return state == 0;
}

int main() {
    char *inputs[] = {"0","00","11","110","1001","0110","000","1010","111111"};
    int n = 9;
    for (int i = 0; i < n; i++)
        printf("%s -> %s\n", inputs[i], divisibleBy3(inputs[i]) ? "VALID" : "INVALID");
    return 0;
}
