#include <stdio.h>
#include <string.h>

/* Operator precedence table for + and *
   Handles: id, +, *, $
   Precedence: * > + */
int isOperator(const char *t) {
    return strcmp(t,"+")==0 || strcmp(t,"*")==0;
}

int isOperand(const char *t) {
    return strcmp(t,"a")==0||strcmp(t,"b")==0||strcmp(t,"id")==0;
}

int main() {
    const char *tokens[] = {"a","+","*","b","$"};
    int n = 5;
    printf("Parsing: a + * b\n\n");
    for (int i = 0; i < n-1; i++) {
        if (isOperator(tokens[i]) && isOperator(tokens[i+1])) {
            printf("ERROR: invalid sequence '%s' followed by '%s'\n",
                tokens[i], tokens[i+1]);
            return 0;
        }
    }
    printf("Parse successful\n");
    return 0;
}
