#include <stdio.h>
#include <string.h>

/* Statements:
   a = b + c
   b = a + d
   Check: does stmt2 depend on a result produced by stmt1? */
typedef struct { char lhs[8]; char rhs1[8]; char rhs2[8]; } Stmt;

int dependsOn(Stmt *s2, const char *var) {
    return strcmp(s2->rhs1,var)==0 || strcmp(s2->rhs2,var)==0;
}

int main() {
    Stmt s1 = {"a","b","c"};
    Stmt s2 = {"b","a","d"};
    printf("Statement 1: %s = %s + %s\n", s1.lhs, s1.rhs1, s1.rhs2);
    printf("Statement 2: %s = %s + %s\n\n", s2.lhs, s2.rhs1, s2.rhs2);
    if (dependsOn(&s2, s1.lhs)) {
        printf("Reordering NOT SAFE\n");
        printf("Reason: Statement 2 uses '%s', which is written by Statement 1.\n", s1.lhs);
    } else {
        printf("Reordering SAFE\n");
    }
    return 0;
}
