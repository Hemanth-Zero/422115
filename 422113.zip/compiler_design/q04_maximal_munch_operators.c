#include <stdio.h>
#include <ctype.h>
#include <string.h>

int main() {
    const char *input = "a===b++c==d=e++++f";
    int i = 0, len = strlen(input);
    while (i < len) {
        char c = input[i];
        if (isalpha(c) || c == '_') {
            char buf[64]; int j = 0;
            while (i < len && (isalnum(input[i]) || input[i]=='_'))
                buf[j++] = input[i++];
            buf[j] = '\0';
            printf("%s ", buf);
        } else if (c == '=') {
            if (input[i+1]=='=' && input[i+2]=='=') { printf("=== "); i+=3; }
            else if (input[i+1]=='=') { printf("== "); i+=2; }
            else { printf("= "); i++; }
        } else if (c == '+') {
            if (input[i+1]=='+') { printf("++ "); i+=2; }
            else { printf("+ "); i++; }
        } else i++;
    }
    printf("\n");
    return 0;
}
