#include <stdio.h>
#include <string.h>

#define MAX 50
typedef struct { char name[32]; int scope; } VarEntry;
VarEntry vars[MAX]; int nv=0;
int currentScope=0;

void enterScope() { currentScope++; }

void exitScope() {
    for (int i=nv-1;i>=0;i--)
        if (vars[i].scope==currentScope) nv=i;
    currentScope--;
}

void declare(const char *name) {
    strcpy(vars[nv].name,name);
    vars[nv].scope=currentScope;
    nv++;
}

int isInScope(const char *name) {
    for (int i=0;i<nv;i++)
        if (strcmp(vars[i].name,name)==0) return 1;
    return 0;
}

int main() {
    declare("x");          /* int x = 5; */
    enterScope();
    declare("y");          /* int y = x + 2; */
    printf("y declared, x in scope: %s\n", isInScope("x")?"YES":"NO");
    exitScope();           /* y destroyed here */

    /* y = y + 1; — use after scope */
    if (!isInScope("y"))
        printf("ERROR: y used outside scope\n");
    printf("Reason: y destroyed after block exit\n");
    return 0;
}
