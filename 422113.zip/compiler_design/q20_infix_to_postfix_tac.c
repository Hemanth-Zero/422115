#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* a + b * c => Postfix: a b c * +
   TAC: t1 = b*c, t2 = a+t1 */
char stk[64][16]; int top2 = -1;
void push(const char *s) { strcpy(stk[++top2], s); }
char* pop2() { return stk[top2--]; }
int prec(char c) { return c=='*'||c=='/'?2:c=='+'||c=='-'?1:0; }

int main() {
    const char *expr = "a+b*c";
    char postfix[256] = "", ops[64]; int op_top = -1;

    /* Shunting-yard */
    for (int i = 0; expr[i]; i++) {
        char c = expr[i];
        if (isalpha(c)) { char s[2]={c,0}; strcat(postfix,s); strcat(postfix," "); }
        else if (c=='+'||c=='*') {
            while (op_top>=0 && prec(ops[op_top])>=prec(c)) {
                char s[2]={ops[op_top--],0}; strcat(postfix,s); strcat(postfix," ");
            }
            ops[++op_top]=c;
        }
    }
    while (op_top>=0) { char s[2]={ops[op_top--],0}; strcat(postfix,s); strcat(postfix," "); }
    printf("Postfix: %s\n", postfix);

    /* Generate TAC from postfix */
    printf("\nTAC:\n");
    int tc=1; char tbuf[16];
    char pf[256]; strcpy(pf, postfix);
    char *tok = strtok(pf, " ");
    top2 = -1;
    while (tok) {
        if (isalpha(tok[0])) push(tok);
        else {
            char *b=pop2(), *a=pop2();
            sprintf(tbuf,"t%d",tc++);
            printf("%s = %s %c %s\n", tbuf, a, tok[0], b);
            push(tbuf);
        }
        tok = strtok(NULL," ");
    }
    return 0;
}
