#include <stdio.h>
#include <string.h>
#include <ctype.h>

/* Simulate two-buffer scheme by concatenating buffers */
char *keywords[] = {"int","float","char","if","while","return"};
int nkw = 6;

int isKeyword(const char *s) {
    for (int i = 0; i < nkw; i++)
        if (strcmp(s, keywords[i])==0) return 1;
    return 0;
}

void classify(const char *tok) {
    if (isKeyword(tok)) printf("%s -> KEYWORD\n", tok);
    else if (isalpha(tok[0])||tok[0]=='_') printf("%s -> IDENTIFIER\n", tok);
    else if (isdigit(tok[0])) printf("%s -> NUMBER\n", tok);
    else printf("%s -> SYMBOL\n", tok);
}

int main() {
    const char *buf1 = "int varNa";
    const char *buf2 = "me = 12345;";
    char combined[128];
    snprintf(combined, sizeof(combined), "%s%s", buf1, buf2);
    char tok[64]; int j = 0;
    for (int i = 0; combined[i]; i++) {
        char c = combined[i];
        if (isalnum(c)||c=='_') { tok[j++]=c; }
        else {
            if (j>0) { tok[j]='\0'; classify(tok); j=0; }
            if (!isspace(c)) { tok[0]=c; tok[1]='\0'; classify(tok); }
        }
    }
    if (j>0) { tok[j]='\0'; classify(tok); }
    return 0;
}
