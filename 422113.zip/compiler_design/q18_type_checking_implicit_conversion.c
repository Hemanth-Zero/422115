#include <stdio.h>
#include <string.h>

/* Types: int=0, float=1, bool=2 */
#define INT   0
#define FLOAT 1
#define BOOL  2

const char* typeName(int t) {
    if (t==INT)   return "int";
    if (t==FLOAT) return "float";
    if (t==BOOL)  return "bool";
    return "unknown";
}

/* Returns result type of op, or -1 if invalid */
int typeCheck(int lhs, int rhs) {
    if (lhs == BOOL || rhs == BOOL) return -1;
    if (lhs == FLOAT || rhs == FLOAT) return FLOAT;
    return INT;
}

void checkAssign(const char *expr, int lhs, int op1, int op2) {
    int rhs = typeCheck(op1, op2);
    if (rhs == -1) {
        printf("%s -> ERROR (bool in arithmetic)\n", expr);
    } else {
        if (lhs == INT && rhs == FLOAT)
            printf("%s -> VALID (float->int conversion may warn)\n", expr);
        else
            printf("%s -> VALID\n", expr);
    }
}

int main() {
    /* a=int, b=float */
    checkAssign("a = b + 3",    INT,   FLOAT, INT);
    checkAssign("b = a + true", FLOAT, INT,   BOOL);
    return 0;
}
