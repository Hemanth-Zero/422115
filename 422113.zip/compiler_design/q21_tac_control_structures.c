#include <stdio.h>

/* if (a < b) x = y + z;
   Generates TAC with labels */
int labelCount = 1;
int newLabel() { return labelCount++; }

int main() {
    int L1 = newLabel(), L2 = newLabel();
    char t1[8]; sprintf(t1,"t%d",1);
    printf("if a < b goto L%d\n", L1);
    printf("goto L%d\n", L2);
    printf("L%d: %s = y + z\n", L1, t1);
    printf("     x = %s\n", t1);
    printf("L%d:\n", L2);
    return 0;
}
