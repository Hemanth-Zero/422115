#include <stdio.h>
#include <string.h>
#include <ctype.h>

const char *keywords[] = {"if","while"};

int isKeyword(const char *s) {
    for (int i=0;i<2;i++) if (strcmp(s,keywords[i])==0) return 1;
    return 0;
}

int main() {
    const char *input = "ifx==y++whilez=10if==a+++b";
    int i=0, n=strlen(input);
    while (i < n) {
        if (input[i]=='=' && input[i+1]=='=') { printf("== -> OPERATOR\n"); i+=2; }
        else if (input[i]=='+' && input[i+1]=='+') { printf("++ -> OPERATOR\n"); i+=2; }
        else if (input[i]=='=') { printf("= -> OPERATOR\n"); i++; }
        else if (input[i]=='+') { printf("+ -> OPERATOR\n"); i++; }
        else if (isdigit(input[i])) {
            char buf[32]; int j=0;
            while (i<n && isdigit(input[i])) buf[j++]=input[i++];
            buf[j]='\0'; printf("%s -> NUMBER\n",buf);
        } else if (isalpha(input[i]) || input[i]=='_') {
            char buf[64]; int j=0;
            while (i<n && (isalnum(input[i])||input[i]=='_')) buf[j++]=input[i++];
            buf[j]='\0';
            printf("%s -> %s\n", buf, isKeyword(buf)?"KEYWORD":"IDENTIFIER");
        } else i++;
    }
    return 0;
}
