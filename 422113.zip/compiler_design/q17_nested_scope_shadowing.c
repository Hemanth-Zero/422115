#include <stdio.h>
#include <string.h>

#define MAXSCOPE 10
#define MAXSYM   20

typedef struct { char name[32]; int value; } Sym;
typedef struct { Sym syms[MAXSYM]; int count; } Scope;

Scope stack[MAXSCOPE];
int top = -1;

void pushScope() { top++; stack[top].count = 0; }
void popScope()  { top--; }

void declare(const char *n, int v) {
    Scope *s = &stack[top];
    strcpy(s->syms[s->count].name, n);
    s->syms[s->count].value = v;
    s->count++;
}

int resolve(const char *n) {
    for (int i = top; i >= 0; i--)
        for (int j = 0; j < stack[i].count; j++)
            if (strcmp(stack[i].syms[j].name, n)==0)
                return stack[i].syms[j].value;
    return -9999;
}

int main() {
    pushScope(); declare("x", 5);
    pushScope(); declare("x", 10);
    pushScope(); declare("y", resolve("x"));
    printf("Inner y uses x = %d\n", resolve("y"));
    popScope();
    popScope();
    popScope();
    return 0;
}
