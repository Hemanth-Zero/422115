    #include<iostream>
    #include<string>
    using namespace std;
    struct sym
    {
        string type;
        string value;
        string id;
        int lvl;
    };

    sym stack[10];
    int top =-1;
    string input;
    int i =0;
    int lvl = 0;
    int scopeno = 0;
    string till(char a )
    {
        string temp ="";
        while(input[i] != a && i< input.size() )
        {
            temp+=input[i];
            i++;
        }
        return temp;
    }
    bool lookup(string id ,int lvl){
        int ftop = top;
        while(ftop>=0){
            sym t = stack[ftop];
            if(t.id == id && t.lvl == lvl){
                return true;
            }
            ftop--;
        }
        ftop = top;
        while(ftop>=0){
            sym t = stack[ftop];
            if(t.id == id and lvl < t.lvl){
                printf("Wrong scope usage");
                exit(0);
            }
            ftop--;
        }
        return false;
    }

    void toend(){
        string t = till(';');
    }

    string lookval(string val,string type){
        int ftop = top;
        while(ftop>=0){
            sym t = stack[ftop];
            if(t.id == val ){
                if(t.type != type){
                    cout<<"Invalid Type assignment val"<<val;
                    exit(0);
                }
                cout<<t.id<<" used of lvl "<<t.lvl<<" of val "<<t.value<<endl;
                return t.value;
            }
            ftop--;
        }
        return val;
    }

    int main(){
        
        getline(cin,input);

        
        while (input[i]!='\0')
        {   
            if(input[i] =='{') {scopeno++; i++; lvl = lvl+scopeno;}
            string type = till(' ');
            i++;
            string id = till('=');
            i++;
            string value = lookval(till(';'),type);
            i++;
            if(lookup(id,lvl)){
                printf("duplicate\n");
                toend();
                continue;
            }
            top++;
            sym b;
            b.type = type;
            b.value = value;
            b.id = id;
            b.lvl = lvl;
            stack[top] = b; 
            if(input[i] =='}') {lvl--;i++;}
        }
        while(top != -1){
            sym r = stack[top];
            cout<<r.type<<" "<<r.id<<" "<<r.value<<" "<<r.lvl<<endl;
            top--;
        }

    }

