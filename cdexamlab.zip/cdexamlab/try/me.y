%{
    #include "stdio.h"
    int yyerror(char *s);
%}

%token NUMBER
%left '*'
%%
expre:
    expre '+' term {$$=$1+$3; printf(" %d",$$);}
    |expre '-' term {$$=$1-$3; printf(" %d",$$);}
    |term  {$$=$1;}
    ;
term:
    term '*' factor {$$=$1*$3; printf(" %d",$$);}
   |factor  {$$=$1;}
    ;
factor:
    NUMBER {$$=$1;}
    | '(' expre ')'  {$$ = $2;}
    ;
%%

int main(){
    yyparse();
}

int yyerror(char *s){
    printf("s");
}