%{
    #include<stdio.h>
    #include<stdlib.h>
    void yyerror(const char*s);
    int yylex(); 
%}


%token NUMBER

%%
expre:
    expre '+' expre { printf(" %d\n", $1+$3); }  // ✅ FIXED
    | NUMBER          { $$ = $1; }
    ;
%%

void yyerror(const char *s){
    printf("Error: %s\n", s);
}

int main(){
    yyparse();
}