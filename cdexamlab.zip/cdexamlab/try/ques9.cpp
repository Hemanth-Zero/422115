#include <iostream>
using namespace std;
int main(){
    while(true){
        int i = 0;
        cout<<"Input\n";
        string line;
        getline(cin,line);
        char A = line[0];
        while(line[i] !='-'){
            i++;
        }
        i+=2;
        if(line[i]!=A){
            cout<<"no left recursion";
           continue;
        }
        i++;
        string alpa = "";
        while(line[i]!='|'){
            alpa+=line[i];
            i++;
        }
        i++;
        string beta = "";
        while(line[i]!='\0'){
            beta+=line[i++];
        }
        cout<<A<<"->"<<beta<<A<<"\'"<<endl;
        cout<<A<<"\'"<<"->"<<alpa<<A<<"\'|"<<"e"<<endl;
    }
}