#include <iostream>
#include <sstream>
#include <map>
#include <vector>
using namespace std;

vector<map<string, int>> scopes;

int lookup(const string &var) {
    for (int i = scopes.size() - 1; i >= 0; i--) {
        if (scopes[i].count(var))
            return scopes[i][var];
    }
    return -1; 
}

int main() {
    string input, line;
    
    while (getline(cin, line)) {
        input += line + " ";
    }

    scopes.push_back({}); 

    stringstream ss(input);
    string token;

    while (ss >> token) {

        // Enter new scope
        if (token == "{") {
            scopes.push_back({});
        }

        // Exit scope
        else if (token == "}") {
            scopes.pop_back();
        }

        
        else if (token == "int") {
            string var, eq, value;
            ss >> var >> eq >> value;

            
            if (value.back() == ';')
                value.pop_back();

            int val;

            
            if (isdigit(value[0])) {
                val = stoi(value);
            }
     
            else {
                val = lookup(value);
            }

            scopes.back()[var] = val;

            
            if (!isdigit(value[0])) {
                cout << var << " uses " << value << " = " << val << endl;
            }
        }
    }

    return 0;
}